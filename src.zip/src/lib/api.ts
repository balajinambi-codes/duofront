const API_URL =
  process.env
    .NEXT_PUBLIC_API_URL;

export async function apiFetch(
  endpoint: string
) {
  try {
    const response = await fetch(
      `${API_URL}${endpoint}`,
      {
        cache: "no-store",
      }
    );

    // DEBUG
    console.log(
      "FETCH:",
      `${API_URL}${endpoint}`
    );

    if (!response.ok) {
      console.error(
        "API ERROR:",
        response.status
      );

      return [];
    }

    return response.json();
  } catch (error) {
    console.error(
      "FETCH FAILED:",
      error
    );

    return [];
  }
}